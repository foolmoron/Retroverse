/**********\
|RETROVERSE|
\**********/

Thanks for downloading!

Install: Unzip folder and run Retroverse/setup.exe.  The game will install and will start up automatically (might take a while to load though)
Uninstall: Go to Add/Remove Programs and remove "Retroverse"

Website: http://people.virginia.edu/~mbk6wm/retroverse.html
IndieDB: http://www.indiedb.com/games/retroverse
Desura: http://www.desura.com/games/retroverse